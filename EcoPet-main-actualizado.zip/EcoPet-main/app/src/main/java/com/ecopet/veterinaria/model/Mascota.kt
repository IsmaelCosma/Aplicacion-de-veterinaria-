package com.ecopet.veterinaria.model

data class Mascota(
    val id: Int = 0,
    val nombre: String,
    val especie: String,
    val raza: String,
    val edad: Int,
    val peso: Double,
    val codigo: String
)
