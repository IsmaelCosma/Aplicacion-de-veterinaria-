package com.ecopet.veterinaria.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ecopet.veterinaria.model.Mascota
import com.ecopet.veterinaria.model.Vacuna
import com.ecopet.veterinaria.ui.theme.EcoForest
import com.ecopet.veterinaria.ui.theme.EcoMint
import com.ecopet.veterinaria.ui.theme.EcoPrimary
import com.ecopet.veterinaria.ui.theme.EcoSky

@Composable
fun PantallaCarnetMascota(
    onVolverInicio: () -> Unit = {}
) {
    val mascota = Mascota(
        id = 1,
        nombre = "Nala",
        especie = "Perro",
        raza = "Labrador Retriever",
        edad = 4,
        peso = 26.5,
        codigo = "PET-00457"
    )

    val vacunas = listOf(
        Vacuna(
            mascotaId = 1,
            nombre = "Rabia",
            fechaAplicacion = "15/02/2026",
            proximaDosis = "15/02/2027"
        ),
        Vacuna(
            mascotaId = 1,
            nombre = "Parvovirus",
            fechaAplicacion = "10/03/2026",
            proximaDosis = "10/03/2027"
        ),
        Vacuna(
            mascotaId = 1,
            nombre = "Moquillo",
            fechaAplicacion = "10/03/2026",
            proximaDosis = "10/03/2027"
        ),
        Vacuna(
            mascotaId = 1,
            nombre = "Leptospirosis",
            fechaAplicacion = "20/04/2026",
            proximaDosis = "20/04/2027"
        ),
        Vacuna(
            mascotaId = 1,
            nombre = "Bordetella",
            fechaAplicacion = "12/05/2026",
            proximaDosis = "12/05/2027"
        ),
        Vacuna(
            mascotaId = 1,
            nombre = "Hepatitis canina",
            fechaAplicacion = "18/06/2026",
            proximaDosis = "18/06/2027"
        )
    )

    Scaffold(
        topBar = {
            TopAppBarCarnet(onVolverInicio)
        },
        containerColor = EcoSky
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                TarjetaMascota(mascota)
            }

            item {
                TarjetaIdentificacion(mascota.codigo)
            }

            item {
                Text(
                    text = "Carnet de vacunación",
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold,
                    color = EcoForest
                )
            }

            items(vacunas) { vacuna ->
                TarjetaVacuna(vacuna)
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFFE4F1FF)
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = Color(0xFF1769AA)
                        )

                        Text(
                            text = "Mantén actualizado el carnet de vacunación " +
                                "de tu mascota. Consulta con tu veterinario " +
                                "las fechas recomendadas para cada dosis.",
                            color = Color(0xFF17466E)
                        )
                    }
                }
            }

            item {
                OutlinedButton(
                    onClick = onVolverInicio,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = null
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Volver al inicio")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopAppBarCarnet(
    onVolverInicio: () -> Unit
) {
    TopAppBar(
        title = {
            Text(
                text = "Carnet Digital",
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        },
        navigationIcon = {
            IconButton(onClick = onVolverInicio) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Volver",
                    tint = Color.White
                )
            }
        },
        actions = {
            Icon(
                imageVector = Icons.Default.Pets,
                contentDescription = "Mascota",
                tint = Color.White,
                modifier = Modifier.padding(end = 16.dp)
            )
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = EcoPrimary
        )
    )
}

@Composable
private fun TarjetaMascota(mascota: Mascota) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .background(
                            EcoMint,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Pets,
                        contentDescription = "Mascota",
                        tint = EcoPrimary,
                        modifier = Modifier.size(42.dp)
                    )
                }

                Column {
                    Text(
                        text = mascota.nombre,
                        fontSize = 27.sp,
                        fontWeight = FontWeight.Bold,
                        color = EcoForest
                    )

                    Text(
                        text = mascota.especie,
                        color = Color.DarkGray
                    )

                    Text(
                        text = mascota.raza,
                        color = Color.Gray
                    )
                }
            }

            Divider(color = Color(0xFFE5ECEA))

            DatoMascota("Edad", "${mascota.edad} años")
            DatoMascota("Peso", "${mascota.peso} kg")
            DatoMascota("Identificación", mascota.codigo)
        }
    }
}

@Composable
private fun DatoMascota(
    titulo: String,
    valor: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = titulo,
            color = Color.Gray
        )
        Text(
            text = valor,
            fontWeight = FontWeight.SemiBold,
            color = EcoForest
        )
    }
}

@Composable
private fun TarjetaIdentificacion(codigo: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = EcoMint
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Código de identificación",
                    color = Color.DarkGray
                )

                Text(
                    text = codigo,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    color = EcoPrimary
                )

                Text(
                    text = "Identificador de la mascota",
                    fontSize = 12.sp,
                    color = Color.DarkGray
                )
            }

            Icon(
                imageVector = Icons.Default.Pets,
                contentDescription = null,
                tint = EcoPrimary,
                modifier = Modifier.size(42.dp)
            )
        }
    }
}

@Composable
private fun TarjetaVacuna(vacuna: Vacuna) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(
                        EcoMint,
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.MedicalServices,
                    contentDescription = null,
                    tint = EcoPrimary
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = vacuna.nombre,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = EcoForest
                )

                Text(
                    text = "Aplicada: ${vacuna.fechaAplicacion}",
                    fontSize = 12.sp,
                    color = Color.DarkGray
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = EcoPrimary
                    )

                    Spacer(Modifier.width(4.dp))

                    Text(
                        text = "Próxima: ${vacuna.proximaDosis}",
                        fontSize = 12.sp,
                        color = Color.DarkGray
                    )
                }
            }

            Surface(
                color = Color(0xFFDDF4E5),
                shape = RoundedCornerShape(50)
            ) {
                Text(
                    text = "Registrada",
                    modifier = Modifier.padding(
                        horizontal = 8.dp,
                        vertical = 5.dp
                    ),
                    fontSize = 10.sp,
                    color = Color(0xFF187544)
                )
            }
        }
    }
}

@Preview(
    showBackground = true,
    showSystemUi = true,
    name = "Carnet Digital de la Mascota"
)
@Composable
fun PreviewPantallaCarnetMascota() {
    MaterialTheme {
        PantallaCarnetMascota()
    }
}
