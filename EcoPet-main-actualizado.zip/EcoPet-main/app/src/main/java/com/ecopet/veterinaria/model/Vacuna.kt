package com.ecopet.veterinaria.model

data class Vacuna(
    val id: Int = 0,
    val mascotaId: Int,
    val nombre: String,
    val fechaAplicacion: String,
    val proximaDosis: String,
    val aplicada: Boolean = true
)
